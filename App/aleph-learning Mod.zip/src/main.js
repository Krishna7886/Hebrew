import { HEBREW_ALPHABET, HEBREW_VOWELS, FLASHCARDS } from './constants.js';
import { getPronunciation, askTutor, textToSpeech } from './geminiService.js';

// --- State Management ---
let state = {
    activeTab: 'alphabet',
    isDark: localStorage.getItem('aleph-theme') === 'dark',
    searchQuery: '',
    selectedCategory: 'All',
    cardIndex: 0,
    stats: JSON.parse(localStorage.getItem('aleph-progress')) || {
        totalScore: 0,
        bestStreak: 0,
        currentStreak: 0,
        flashcardMastery: {}
    },
    quiz: {
        type: null,
        currentQuestion: null,
        options: [],
        sessionScore: 0,
        totalAnswered: 0,
        feedback: null
    },
    chat: {
        messages: [
            { role: 'model', text: "Shalom! I'm your Hebrew tutor. Ask me anything about Hebrew grammar, vocabulary, or how to pronounce words!" }
        ],
        isLoading: false,
        playingIndex: null,
        loadingIndex: null
    }
};

// --- Audio Logic ---
let sharedAudioContext = null;

async function playRawAudio(base64Data) {
    if (base64Data === "FALLBACK_TO_BROWSER") return;
    try {
        if (!sharedAudioContext) {
            sharedAudioContext = new (window.AudioContext || window.webkitAudioContext)({ sampleRate: 24000 });
        }
        if (sharedAudioContext.state === 'suspended') {
            await sharedAudioContext.resume();
        }

        const binaryString = window.atob(base64Data);
        const len = binaryString.length;
        const bytes = new Uint8Array(len);
        for (let i = 0; i < len; i++) {
            bytes[i] = binaryString.charCodeAt(i);
        }
        
        const int16Array = new Int16Array(bytes.buffer);
        const float32Array = new Float32Array(int16Array.length);
        for (let i = 0; i < int16Array.length; i++) {
            float32Array[i] = int16Array[i] / 32768;
        }

        const audioBuffer = sharedAudioContext.createBuffer(1, float32Array.length, 24000);
        audioBuffer.getChannelData(0).set(float32Array);

        const source = sharedAudioContext.createBufferSource();
        source.buffer = audioBuffer;
        source.connect(sharedAudioContext.destination);
        source.start();
        
        return new Promise((resolve) => {
            source.onended = () => resolve();
        });
    } catch (err) {
        console.error("Error playing raw audio:", err);
    }
}

function speakWithBrowser(text) {
    return new Promise((resolve) => {
        const utterance = new SpeechSynthesisUtterance(text);
        utterance.lang = 'he-IL';
        utterance.rate = 0.9;
        utterance.onend = () => resolve();
        utterance.onerror = () => resolve();
        window.speechSynthesis.speak(utterance);
    });
}

// --- Utilities ---
function saveState() {
    localStorage.setItem('aleph-progress', JSON.stringify(state.stats));
    localStorage.setItem('aleph-theme', state.isDark ? 'dark' : 'light');
}

function updateTheme() {
    if (state.isDark) {
        document.body.classList.add('dark');
        document.body.classList.remove('bg-stone-50');
        document.body.classList.add('bg-stone-950');
    } else {
        document.body.classList.remove('dark');
        document.body.classList.add('bg-stone-50');
        document.body.classList.remove('bg-stone-950');
    }
    const themeToggle = document.getElementById('theme-toggle');
    if (themeToggle) {
        themeToggle.querySelector('.dark-icon').classList.toggle('hidden', state.isDark);
        themeToggle.querySelector('.light-icon').classList.toggle('hidden', !state.isDark);
    }
}

// --- Rendering Logic ---
const mainContent = document.getElementById('main-content');

function render() {
    mainContent.innerHTML = '';
    
    // Update active tab buttons
    document.querySelectorAll('[data-tab]').forEach(btn => {
        const tab = btn.getAttribute('data-tab');
        if (tab === state.activeTab) {
            btn.classList.add('active');
        } else {
            btn.classList.remove('active');
        }
    });

    if (state.activeTab === 'alphabet') renderAlphabet();
    else if (state.activeTab === 'flashcards') renderFlashcards();
    else if (state.activeTab === 'practice') renderPractice();
    else if (state.activeTab === 'tutor') renderTutor();

    // Re-initialize Lucide icons
    lucide.createIcons();
}

function renderAlphabet() {
    const section = document.createElement('div');
    section.className = 'space-y-12 animate-in fade-in slide-in-from-bottom-4 duration-500';
    
    section.innerHTML = `
        <div class="text-center max-w-2xl mx-auto">
            <h2 class="text-5xl font-black text-stone-900 dark:text-white mb-4 tracking-tight">The Alef-Bet</h2>
            <p class="text-stone-500 dark:text-stone-400 font-medium">Tap any letter to hear its pronunciation. Hebrew is read from right to left!</p>
        </div>
        <div class="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-6" id="alphabet-grid"></div>

        <div class="text-center max-w-2xl mx-auto pt-16">
            <h2 class="text-4xl font-black text-stone-900 dark:text-white mb-4 tracking-tight">Vowels (Niqqud)</h2>
            <p class="text-stone-500 dark:text-stone-400 font-medium">Vowels are marks added to letters to indicate sound. Here they are shown with Aleph (א).</p>
        </div>
        <div class="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-6" id="vowels-grid"></div>
    `;

    mainContent.appendChild(section);

    const alphabetGrid = document.getElementById('alphabet-grid');
    HEBREW_ALPHABET.forEach(letter => {
        alphabetGrid.appendChild(createAlphabetCard(letter));
    });

    const vowelsGrid = document.getElementById('vowels-grid');
    HEBREW_VOWELS.forEach(vowel => {
        vowelsGrid.appendChild(createAlphabetCard(vowel));
    });
}

function createAlphabetCard(letter) {
    const card = document.createElement('div');
    card.className = 'relative group';
    card.innerHTML = `
        <div class="glass-card p-6 rounded-2xl flex flex-col items-center justify-center gap-3 cursor-pointer group relative overflow-hidden transition-all hover:scale-105 hover:-translate-y-1 active:scale-95">
            <div class="absolute inset-0 bg-gradient-to-br from-emerald-500/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity"></div>
            <span class="hebrew-text text-6xl font-bold bg-clip-text text-transparent bg-gradient-to-br from-emerald-600 to-teal-500 group-hover:from-emerald-500 group-hover:to-teal-400 transition-all drop-shadow-sm">
                ${letter.char}
            </span>
            <div class="text-center relative z-10">
                <p class="text-sm font-bold text-stone-700 dark:text-stone-200">${letter.name}</p>
                <p class="text-xs text-stone-500 dark:text-stone-400 italic font-medium">${letter.transliteration}</p>
            </div>
            <div class="audio-status">
                <i data-lucide="volume-2" class="w-5 h-5 text-stone-300 dark:text-stone-600 group-hover:text-emerald-500 transition-colors"></i>
            </div>
        </div>
    `;

    card.addEventListener('click', async () => {
        const statusIcon = card.querySelector('.audio-status');
        statusIcon.innerHTML = '<i data-lucide="loader-2" class="w-5 h-5 text-emerald-500 animate-spin"></i>';
        lucide.createIcons();

        try {
            if (letter.audio) {
                const audio = new Audio(letter.audio);
                await audio.play();
            } else {
                const base64 = await getPronunciation(letter.char);
                if (base64 === "FALLBACK_TO_BROWSER") {
                    await speakWithBrowser(letter.char);
                } else if (base64) {
                    await playRawAudio(base64);
                }
            }
        } catch (err) {
            await speakWithBrowser(letter.char);
        } finally {
            statusIcon.innerHTML = '<i data-lucide="volume-2" class="w-5 h-5 text-emerald-500 animate-pulse"></i>';
            lucide.createIcons();
            setTimeout(() => {
                statusIcon.innerHTML = '<i data-lucide="volume-2" class="w-5 h-5 text-stone-300 dark:text-stone-600 group-hover:text-emerald-500 transition-colors"></i>';
                lucide.createIcons();
            }, 1000);
        }
    });

    return card;
}

function renderFlashcards() {
    const categories = ['All', ...new Set(FLASHCARDS.map(c => c.category))];
    const filteredCards = FLASHCARDS.filter(card => {
        const matchesSearch = card.hebrew.includes(state.searchQuery) || 
                             card.english.toLowerCase().includes(state.searchQuery.toLowerCase()) ||
                             card.transliteration.toLowerCase().includes(state.searchQuery.toLowerCase());
        const matchesCategory = (state.selectedCategory === 'All' || card.category === state.selectedCategory);
        return matchesSearch && matchesCategory;
    });

    const section = document.createElement('div');
    section.className = 'space-y-8 max-w-2xl mx-auto animate-in fade-in slide-in-from-bottom-4 duration-500';
    
    section.innerHTML = `
        <div class="text-center">
            <h2 class="text-5xl font-black text-stone-900 dark:text-white mb-4 tracking-tight">Vocabulary</h2>
            <p class="text-stone-500 dark:text-stone-400 font-medium">Master common phrases with interactive cards.</p>
        </div>

        <div class="flex flex-col md:flex-row gap-4">
            <div class="flex-1 relative">
                <input
                    type="text"
                    id="flashcard-search"
                    placeholder="Search words..."
                    value="${state.searchQuery}"
                    class="w-full glass-card border-none rounded-2xl px-6 py-4 outline-none focus:ring-2 focus:ring-emerald-500 dark:text-white"
                />
            </div>
            <select
                id="flashcard-category"
                class="glass-card border-none rounded-2xl px-6 py-4 outline-none focus:ring-2 focus:ring-emerald-500 dark:text-white appearance-none cursor-pointer"
            >
                ${categories.map(cat => `<option value="${cat}" ${state.selectedCategory === cat ? 'selected' : ''} class="dark:bg-stone-900">${cat}</option>`).join('')}
            </select>
            <button
                id="shuffle-btn"
                class="glass-card p-4 rounded-2xl text-emerald-600 hover:scale-110 transition-transform"
                title="Shuffle"
            >
                <i data-lucide="refresh-cw" class="w-6 h-6"></i>
            </button>
        </div>
        
        <div class="relative max-w-lg mx-auto" id="flashcard-container"></div>
    `;

    mainContent.appendChild(section);

    const container = document.getElementById('flashcard-container');
    if (filteredCards.length > 0) {
        const card = filteredCards[state.cardIndex];
        const mastery = state.stats.flashcardMastery[card.hebrew];
        
        container.innerHTML = `
            <div class="perspective-1000 w-full h-80 cursor-pointer group/card" id="flashcard-flip">
                <div class="flashcard-inner" id="flashcard-inner">
                    <!-- Front -->
                    <div class="flashcard-front glass-card flex flex-col items-center justify-center p-8">
                        <div class="absolute top-4 right-4 flex gap-2">
                            <button data-mastery="struggling" class="p-2 rounded-lg transition-all ${mastery === 'struggling' ? 'bg-rose-500 text-white' : 'bg-stone-100 dark:bg-stone-800 text-stone-400 hover:text-rose-500'}">
                                <i data-lucide="thumbs-down" class="w-4 h-4"></i>
                            </button>
                            <button data-mastery="mastered" class="p-2 rounded-lg transition-all ${mastery === 'mastered' ? 'bg-emerald-500 text-white' : 'bg-stone-100 dark:bg-stone-800 text-stone-400 hover:text-emerald-500'}">
                                <i data-lucide="thumbs-up" class="w-4 h-4"></i>
                            </button>
                        </div>
                        <span class="hebrew-text text-8xl font-bold bg-clip-text text-transparent bg-gradient-to-br from-emerald-600 to-teal-500 mb-6 drop-shadow-md">
                            ${card.hebrew}
                        </span>
                        <button id="play-card-audio" class="p-4 rounded-full bg-emerald-50 dark:bg-emerald-900/30 text-emerald-600 hover:scale-110 transition-transform">
                            <i data-lucide="volume-2" class="w-8 h-8"></i>
                        </button>
                        <p class="mt-6 text-stone-400 dark:text-stone-500 text-xs uppercase tracking-[0.2em] font-bold">Tap to reveal</p>
                    </div>
                    <!-- Back -->
                    <div class="flashcard-back bg-gradient-to-br from-emerald-600 to-teal-700 flex flex-col items-center justify-center p-8 text-white text-center">
                        <p class="text-xl font-medium opacity-70 mb-2 tracking-wide">${card.transliteration}</p>
                        <h3 class="text-4xl font-bold mb-4 drop-shadow-sm">${card.english}</h3>
                        ${card.exampleSentence ? `
                            <div class="mt-4 p-4 bg-white/10 rounded-2xl backdrop-blur-sm border border-white/10 w-full">
                                <p class="hebrew-text text-2xl mb-1">${card.exampleSentence}</p>
                                <p class="text-xs opacity-60 uppercase tracking-widest font-bold">Example Sentence</p>
                            </div>
                        ` : ''}
                        <div class="mt-6 flex items-center gap-3">
                            <span class="px-4 py-1.5 bg-white/20 rounded-full text-xs font-bold uppercase tracking-widest border border-white/20">${card.category}</span>
                            ${mastery ? `<span class="px-4 py-1.5 rounded-full text-xs font-bold uppercase tracking-widest border ${mastery === 'mastered' ? 'bg-emerald-400/20 border-emerald-400/40 text-emerald-200' : 'bg-rose-400/20 border-rose-400/40 text-rose-200'}">${mastery}</span>` : ''}
                        </div>
                    </div>
                </div>
            </div>
            <div class="flex items-center justify-between mt-10">
                <button id="prev-card" class="p-4 rounded-2xl bg-white dark:bg-stone-900 shadow-xl hover:scale-110 text-stone-600 dark:text-stone-400 transition-all border border-stone-100 dark:border-stone-800">
                    <i data-lucide="chevron-left" class="w-8 h-8"></i>
                </button>
                <div class="flex flex-col items-center">
                    <span class="text-emerald-600 font-black text-lg">${state.cardIndex + 1}</span>
                    <span class="text-stone-400 dark:text-stone-600 text-[10px] font-bold uppercase tracking-widest">OF ${filteredCards.length}</span>
                </div>
                <button id="next-card" class="p-4 rounded-2xl bg-white dark:bg-stone-900 shadow-xl hover:scale-110 text-stone-600 dark:text-stone-400 transition-all border border-stone-100 dark:border-stone-800">
                    <i data-lucide="chevron-right" class="w-8 h-8"></i>
                </button>
            </div>
        `;

        // Event Listeners for Flashcards
        document.getElementById('flashcard-flip').addEventListener('click', () => {
            document.getElementById('flashcard-inner').classList.toggle('flipped');
        });

        document.getElementById('play-card-audio').addEventListener('click', async (e) => {
            e.stopPropagation();
            const btn = e.currentTarget;
            btn.innerHTML = '<i data-lucide="loader-2" class="w-8 h-8 animate-spin"></i>';
            lucide.createIcons();
            try {
                if (card.audio) {
                    const audio = new Audio(card.audio);
                    await audio.play();
                } else {
                    const base64 = await getPronunciation(card.hebrew);
                    if (base64 === "FALLBACK_TO_BROWSER") await speakWithBrowser(card.hebrew);
                    else if (base64) await playRawAudio(base64);
                }
            } catch (err) {
                await speakWithBrowser(card.hebrew);
            } finally {
                btn.innerHTML = '<i data-lucide="volume-2" class="w-8 h-8 animate-pulse"></i>';
                lucide.createIcons();
                setTimeout(() => {
                    btn.innerHTML = '<i data-lucide="volume-2" class="w-8 h-8"></i>';
                    lucide.createIcons();
                }, 1000);
            }
        });

        document.querySelectorAll('[data-mastery]').forEach(btn => {
            btn.addEventListener('click', (e) => {
                e.stopPropagation();
                const newStatus = btn.getAttribute('data-mastery');
                const currentStatus = state.stats.flashcardMastery[card.hebrew];
                state.stats.flashcardMastery[card.hebrew] = newStatus === currentStatus ? 'learning' : newStatus;
                saveState();
                renderFlashcards();
            });
        });

        document.getElementById('prev-card').addEventListener('click', () => {
            state.cardIndex = (state.cardIndex - 1 + filteredCards.length) % filteredCards.length;
            renderFlashcards();
        });

        document.getElementById('next-card').addEventListener('click', () => {
            state.cardIndex = (state.cardIndex + 1) % filteredCards.length;
            renderFlashcards();
        });

    } else {
        container.innerHTML = `
            <div class="glass-card p-12 rounded-3xl text-center">
                <i data-lucide="alert-circle" class="w-12 h-12 text-stone-300 mx-auto mb-4"></i>
                <p class="text-stone-500 font-medium">No words found matching your search.</p>
            </div>
        `;
    }

    // Search and Category Listeners
    document.getElementById('flashcard-search').addEventListener('input', (e) => {
        state.searchQuery = e.target.value;
        state.cardIndex = 0;
        renderFlashcards();
    });

    document.getElementById('flashcard-category').addEventListener('change', (e) => {
        state.selectedCategory = e.target.value;
        state.cardIndex = 0;
        renderFlashcards();
    });

    document.getElementById('shuffle-btn').addEventListener('click', () => {
        state.cardIndex = Math.floor(Math.random() * filteredCards.length);
        renderFlashcards();
    });
}

function renderPractice() {
    const section = document.createElement('div');
    section.className = 'space-y-12 animate-in fade-in slide-in-from-bottom-4 duration-500';
    
    if (!state.quiz.type) {
        section.innerHTML = `
            <div class="text-center max-w-2xl mx-auto">
                <h2 class="text-5xl font-black text-stone-900 dark:text-white mb-4 tracking-tight">Practice Mode</h2>
                <p class="text-stone-500 dark:text-stone-400 font-medium">Challenge yourself and track your progress.</p>
            </div>
            <div class="grid grid-cols-1 sm:grid-cols-3 gap-4 max-w-3xl mx-auto">
                <div class="glass-card p-6 rounded-2xl text-center">
                    <i data-lucide="trophy" class="w-6 h-6 text-amber-500 mx-auto mb-2"></i>
                    <p class="text-2xl font-black text-stone-800 dark:text-white">${state.stats.totalScore}</p>
                    <p class="text-xs text-stone-500 uppercase tracking-widest font-bold">Total Score</p>
                </div>
                <div class="glass-card p-6 rounded-2xl text-center relative overflow-hidden">
                    <div class="absolute top-0 right-0 p-1">
                        <i data-lucide="flame" class="w-4 h-4 ${state.stats.currentStreak > 0 ? 'text-orange-500 animate-pulse' : 'text-stone-300'}"></i>
                    </div>
                    <p class="text-2xl font-black text-stone-800 dark:text-white">${state.stats.currentStreak}</p>
                    <p class="text-xs text-stone-500 uppercase tracking-widest font-bold">Current Streak</p>
                </div>
                <div class="glass-card p-6 rounded-2xl text-center">
                    <i data-lucide="check-circle-2" class="w-6 h-6 text-emerald-500 mx-auto mb-2"></i>
                    <p class="text-2xl font-black text-stone-800 dark:text-white">${state.stats.bestStreak}</p>
                    <p class="text-xs text-stone-500 uppercase tracking-widest font-bold">Best Streak</p>
                </div>
            </div>
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-2xl mx-auto">
                <div class="glass-card p-8 rounded-3xl text-center cursor-pointer group transition-all hover:scale-105 hover:-translate-y-1" id="start-alphabet-quiz">
                    <div class="w-16 h-16 bg-emerald-100 dark:bg-emerald-900/30 rounded-2xl flex items-center justify-center mx-auto mb-6 group-hover:scale-110 transition-transform">
                        <i data-lucide="graduation-cap" class="w-8 h-8 text-emerald-600"></i>
                    </div>
                    <h3 class="text-2xl font-black text-stone-800 dark:text-white mb-2">Alphabet Quiz</h3>
                    <p class="text-stone-500 dark:text-stone-400">Test your knowledge of letters and vowels.</p>
                </div>
                <div class="glass-card p-8 rounded-3xl text-center cursor-pointer group transition-all hover:scale-105 hover:-translate-y-1" id="start-vocab-quiz">
                    <div class="w-16 h-16 bg-teal-100 dark:bg-teal-900/30 rounded-2xl flex items-center justify-center mx-auto mb-6 group-hover:scale-110 transition-transform">
                        <i data-lucide="book-open" class="w-8 h-8 text-teal-600"></i>
                    </div>
                    <h3 class="text-2xl font-black text-stone-800 dark:text-white mb-2">Vocabulary Quiz</h3>
                    <p class="text-stone-500 dark:text-stone-400">Translate common words and phrases.</p>
                </div>
            </div>
        `;
        mainContent.appendChild(section);

        document.getElementById('start-alphabet-quiz').addEventListener('click', () => startQuiz('alphabet'));
        document.getElementById('start-vocab-quiz').addEventListener('click', () => startQuiz('vocabulary'));
    } else {
        section.innerHTML = `
            <div class="max-w-xl mx-auto space-y-8">
                <div class="flex items-center justify-between glass-card p-4 rounded-2xl">
                    <button id="exit-quiz" class="text-stone-500 hover:text-stone-800 dark:hover:text-stone-200 font-bold text-sm flex items-center gap-2">
                        <i data-lucide="x" class="w-4 h-4"></i> Exit Quiz
                    </button>
                    <div class="flex items-center gap-4">
                        <div class="flex items-center gap-2">
                            <i data-lucide="flame" class="w-4 h-4 ${state.stats.currentStreak > 0 ? 'text-orange-500 animate-pulse' : 'text-stone-300'}"></i>
                            <span class="font-black text-stone-800 dark:text-white">${state.stats.currentStreak}</span>
                        </div>
                        <div class="h-4 w-px bg-stone-200 dark:border-stone-800"></div>
                        <div class="flex items-center gap-2">
                            <i data-lucide="trophy" class="w-4 h-4 text-amber-500"></i>
                            <span class="font-black text-stone-800 dark:text-white">${state.quiz.sessionScore}</span>
                        </div>
                        <div class="h-4 w-px bg-stone-200 dark:border-stone-800"></div>
                        <span class="text-stone-400 text-xs font-bold uppercase tracking-widest">Question ${state.quiz.totalAnswered + 1}</span>
                    </div>
                </div>

                <div class="glass-card p-12 rounded-[2.5rem] text-center relative overflow-hidden">
                    <div class="absolute top-0 left-0 w-full h-1 bg-stone-100 dark:bg-stone-800">
                        <div id="quiz-progress" class="h-full bg-emerald-500 transition-all duration-1500" style="width: 0%"></div>
                    </div>
                    <h4 class="text-stone-400 dark:text-stone-500 text-xs font-black uppercase tracking-[0.3em] mb-8">What is this?</h4>
                    <span class="hebrew-text text-9xl font-black bg-clip-text text-transparent bg-gradient-to-br from-emerald-600 to-teal-500 drop-shadow-xl">
                        ${state.quiz.type === 'alphabet' ? state.quiz.currentQuestion.char : state.quiz.currentQuestion.hebrew}
                    </span>
                </div>

                <div class="grid grid-cols-1 sm:grid-cols-2 gap-4" id="quiz-options"></div>
                <div id="quiz-feedback" class="text-center font-black text-xl h-8"></div>
            </div>
        `;
        mainContent.appendChild(section);

        const optionsGrid = document.getElementById('quiz-options');
        state.quiz.options.forEach(option => {
            const btn = document.createElement('button');
            btn.className = 'p-6 rounded-2xl font-bold text-lg transition-all border-2 text-center glass-card border-transparent hover:border-emerald-500/50 text-stone-700 dark:text-stone-200';
            btn.innerText = option;
            btn.addEventListener('click', () => handleAnswer(option, btn));
            optionsGrid.appendChild(btn);
        });

        document.getElementById('exit-quiz').addEventListener('click', () => {
            state.quiz.type = null;
            render();
        });
    }
}

function startQuiz(type) {
    state.quiz.type = type;
    state.quiz.sessionScore = 0;
    state.quiz.totalAnswered = 0;
    generateQuestion();
    render();
}

function generateQuestion() {
    const type = state.quiz.type;
    state.quiz.feedback = null;
    if (type === 'alphabet') {
        const allItems = [...HEBREW_ALPHABET, ...HEBREW_VOWELS];
        const correct = allItems[Math.floor(Math.random() * allItems.length)];
        const others = allItems
            .filter(i => i.name !== correct.name)
            .sort(() => 0.5 - Math.random())
            .slice(0, 3);
        state.quiz.currentQuestion = correct;
        state.quiz.options = [correct.name, ...others.map(o => o.name)].sort(() => 0.5 - Math.random());
    } else {
        const correct = FLASHCARDS[Math.floor(Math.random() * FLASHCARDS.length)];
        const others = FLASHCARDS
            .filter(i => i.english !== correct.english)
            .sort(() => 0.5 - Math.random())
            .slice(0, 3);
        state.quiz.currentQuestion = correct;
        state.quiz.options = [correct.english, ...others.map(o => o.english)].sort(() => 0.5 - Math.random());
    }
}

async function handleAnswer(answer, btn) {
    if (state.quiz.feedback) return;

    const isCorrect = state.quiz.type === 'alphabet' 
        ? answer === state.quiz.currentQuestion.name 
        : answer === state.quiz.currentQuestion.english;

    state.quiz.feedback = isCorrect ? 'correct' : 'incorrect';
    state.quiz.totalAnswered++;

    if (isCorrect) {
        state.quiz.sessionScore++;
        state.stats.totalScore++;
        state.stats.currentStreak++;
        state.stats.bestStreak = Math.max(state.stats.bestStreak, state.stats.currentStreak);
        btn.classList.add('bg-emerald-500', 'border-emerald-400', 'text-white', 'shadow-lg', 'shadow-emerald-500/20');
        document.getElementById('quiz-feedback').innerHTML = '<span class="text-emerald-500 flex items-center justify-center gap-2"><i data-lucide="check-circle-2" class="w-6 h-6"></i> Correct!</span>';
        confetti({ particleCount: 100, spread: 70, origin: { y: 0.6 } });
        
        const textToPlay = state.quiz.type === 'alphabet' ? state.quiz.currentQuestion.char : state.quiz.currentQuestion.hebrew;
        const base64 = await getPronunciation(textToPlay);
        if (base64 === "FALLBACK_TO_BROWSER") await speakWithBrowser(textToPlay);
        else if (base64) await playRawAudio(base64);
    } else {
        state.stats.currentStreak = 0;
        btn.classList.add('bg-rose-500', 'border-rose-400', 'text-white', 'opacity-50');
        document.getElementById('quiz-feedback').innerHTML = '<span class="text-rose-500">Incorrect, try the next one!</span>';
        // Highlight correct answer
        document.querySelectorAll('#quiz-options button').forEach(b => {
            if (b.innerText === (state.quiz.type === 'alphabet' ? state.quiz.currentQuestion.name : state.quiz.currentQuestion.english)) {
                b.classList.add('bg-emerald-500/50', 'border-emerald-400', 'text-white');
            }
        });
    }

    document.getElementById('quiz-progress').style.width = '100%';
    lucide.createIcons();
    saveState();

    setTimeout(() => {
        generateQuestion();
        render();
    }, 2000);
}

function renderTutor() {
    const section = document.createElement('div');
    section.className = 'max-w-2xl mx-auto space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500';
    
    section.innerHTML = `
        <div class="text-center">
            <h2 class="text-4xl font-bold text-stone-900 dark:text-white mb-4">Personal Tutor</h2>
            <p class="text-stone-500 dark:text-stone-400">Stuck on a rule? Ask our AI tutor for help anytime.</p>
        </div>
        <div class="bg-white dark:bg-stone-900 rounded-3xl shadow-2xl border border-stone-100 dark:border-stone-800 flex flex-col h-[600px] overflow-hidden">
            <div class="p-6 border-b border-stone-100 dark:border-stone-800 bg-stone-50 dark:bg-stone-900/50 flex items-center gap-3">
                <div class="w-10 h-10 rounded-full bg-emerald-100 dark:bg-emerald-900/30 flex items-center justify-center">
                    <i data-lucide="message-square" class="w-5 h-5 text-emerald-600"></i>
                </div>
                <div>
                    <h3 class="font-bold text-stone-800 dark:text-white">AI Hebrew Tutor</h3>
                    <p class="text-xs text-stone-500 dark:text-stone-400">Always online to help</p>
                </div>
            </div>

            <div class="flex-1 overflow-y-auto p-6 space-y-4" id="chat-messages"></div>

            <div class="p-4 border-t border-stone-100 dark:border-stone-800 flex gap-2">
                <input
                    type="text"
                    id="chat-input"
                    placeholder="Ask about a word or rule..."
                    class="flex-1 bg-stone-50 dark:bg-stone-800 border-none rounded-xl px-4 py-2 text-sm focus:ring-2 focus:ring-emerald-500 outline-none dark:text-white"
                />
                <button 
                    id="send-btn"
                    class="bg-emerald-600 text-white p-2 rounded-xl hover:bg-emerald-700 transition-colors disabled:opacity-50"
                >
                    <i data-lucide="chevron-right" class="w-5 h-5"></i>
                </button>
            </div>
        </div>
    `;

    mainContent.appendChild(section);
    renderMessages();

    const input = document.getElementById('chat-input');
    const sendBtn = document.getElementById('send-btn');

    sendBtn.addEventListener('click', handleSendMessage);
    input.addEventListener('keydown', (e) => e.key === 'Enter' && handleSendMessage());
}

function renderMessages() {
    const container = document.getElementById('chat-messages');
    if (!container) return;
    container.innerHTML = '';
    
    state.chat.messages.forEach((msg, i) => {
        const div = document.createElement('div');
        div.className = `flex flex-col ${msg.role === 'user' ? 'items-end' : 'items-start'}`;
        div.innerHTML = `
            <div class="max-w-[80%] p-4 rounded-2xl text-sm relative group ${msg.role === 'user' ? 'bg-emerald-600 text-white rounded-tr-none' : 'bg-stone-100 dark:bg-stone-800 text-stone-800 dark:text-stone-200 rounded-tl-none'}">
                <div class="markdown-body">${marked.parse(msg.text)}</div>
                ${msg.role === 'model' ? `
                    <button class="speak-msg-btn absolute -right-10 top-2 p-2 rounded-full bg-white dark:bg-stone-900 shadow-sm border border-stone-100 dark:border-stone-800 text-stone-400 hover:text-emerald-600 transition-all opacity-0 group-hover:opacity-100 ${state.chat.playingIndex === i || state.chat.loadingIndex === i ? 'opacity-100 text-emerald-600' : ''}" data-index="${i}">
                        <i data-lucide="${state.chat.loadingIndex === i ? 'loader-2' : 'volume-2'}" class="w-4 h-4 ${state.chat.loadingIndex === i ? 'animate-spin' : ''} ${state.chat.playingIndex === i ? 'animate-pulse' : ''}"></i>
                    </button>
                ` : ''}
            </div>
        `;
        container.appendChild(div);
    });

    if (state.chat.isLoading) {
        const loading = document.createElement('div');
        loading.className = 'flex justify-start';
        loading.innerHTML = `
            <div class="bg-stone-100 dark:bg-stone-800 p-4 rounded-2xl rounded-tl-none flex gap-1">
                <span class="w-1.5 h-1.5 bg-stone-400 rounded-full animate-bounce"></span>
                <span class="w-1.5 h-1.5 bg-stone-400 rounded-full animate-bounce [animation-delay:0.2s]"></span>
                <span class="w-1.5 h-1.5 bg-stone-400 rounded-full animate-bounce [animation-delay:0.4s]"></span>
            </div>
        `;
        container.appendChild(loading);
    }

    container.scrollTop = container.scrollHeight;
    lucide.createIcons();

    document.querySelectorAll('.speak-msg-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            const index = parseInt(btn.getAttribute('data-index'));
            speakMessage(state.chat.messages[index].text, index);
        });
    });
}

async function handleSendMessage() {
    const input = document.getElementById('chat-input');
    const text = input.value.trim();
    if (!text || state.chat.isLoading) return;

    input.value = '';
    state.chat.messages.push({ role: 'user', text });
    state.chat.isLoading = true;
    renderMessages();

    try {
        const response = await askTutor(text, state.chat.messages.slice(0, -1));
        if (response === "QUOTA_EXCEEDED") {
            state.chat.messages.push({ role: 'model', text: "I'm sorry, I've reached my usage limit for now. Please try again later, or use the other learning tools in the app!" });
        } else {
            state.chat.messages.push({ role: 'model', text: response || "I'm sorry, I couldn't process that." });
        }
    } catch (error) {
        state.chat.messages.push({ role: 'model', text: "Error connecting to tutor. Please try again." });
    } finally {
        state.chat.isLoading = false;
        renderMessages();
    }
}

async function speakMessage(text, index) {
    if (state.chat.playingIndex !== null || state.chat.loadingIndex !== null) return;
    state.chat.loadingIndex = index;
    renderMessages();
    
    try {
        const cleanText = text.replace(/[*_#`]/g, '');
        const base64 = await textToSpeech(cleanText);
        state.chat.loadingIndex = null;
        if (base64 === "FALLBACK_TO_BROWSER") {
            state.chat.playingIndex = index;
            renderMessages();
            await speakWithBrowser(cleanText);
        } else if (base64) {
            state.chat.playingIndex = index;
            renderMessages();
            await playRawAudio(base64);
        }
    } finally {
        state.chat.loadingIndex = null;
        state.chat.playingIndex = null;
        renderMessages();
    }
}

// --- Initialization ---
document.addEventListener('DOMContentLoaded', () => {
    updateTheme();
    render();

    // Tab switching
    document.querySelectorAll('[data-tab]').forEach(btn => {
        btn.addEventListener('click', () => {
            state.activeTab = btn.getAttribute('data-tab');
            render();
        });
    });

    // Theme toggle
    document.getElementById('theme-toggle').addEventListener('click', () => {
        state.isDark = !state.isDark;
        updateTheme();
        saveState();
    });
});
